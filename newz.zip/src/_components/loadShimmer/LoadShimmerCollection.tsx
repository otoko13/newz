import React from 'react';
import LoadShimmer from './LoadShimmer';

const LoadShimmerCollection = () =>
    <>
        <LoadShimmer />
        <LoadShimmer />
    </>

export default LoadShimmerCollection;