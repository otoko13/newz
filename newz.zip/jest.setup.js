const styling = require('office-ui-fabric-react/lib-commonjs/Styling');

styling.setIconOptions({
    disableWarnings: true,
});